package pom;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

/*Test case where user search for an HP mouse
 * First Searching for mouse, then filtering by brand
 * once the HP filter is selected, filter by condition (new).
 * And click the first option.
 * For last, click on "buy now" to perform the buy and the user
 * should be taken to sing-in page.
*/

public class TestAmazonSearch {

	private WebDriver driver;
	AmazonHomePage AmazonFirstPage;

	@Before
	public void setUp() throws Exception {

		AmazonFirstPage = new AmazonHomePage(driver);
		driver = AmazonFirstPage.chormeDriverConnection();
		AmazonFirstPage.visit("https://www.amazon.com/");
		AmazonFirstPage.Maximize();

	}

	@After
	public void tearDown() throws Exception {
		driver.quit();

	}

	@Test
	public void test() {

		AmazonFirstPage = new AmazonHomePage(driver);

		AmazonFirstPage.searchByDepartament(6);
		AmazonFirstPage.TextSearchProducT("Hp mouse");
		AmazonFirstPage.filterByBrand();
		AmazonFirstPage.SelectProduct();
		AmazonFirstPage.BuyProductNow();
		assertTrue(AmazonFirstPage.DepartmentNameIsDisplayed());

	}

}
