package Locators;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class mercuryTours {

	private WebDriver driver;
	
	By registerLinkLocator = By.linkText("REGISTER");
	By registerPageLocator = By.xpath("//img[@src='/images/nav/logo.gif']");
	By userNameLocator = By.id("email");
	By passwordLocator = By.name("password");
	By confirmPasswordLocator = By.cssSelector("input[name='confirmPassword']");
	By registerBtnLocator = By.name("register");
	
	
	
	By userNameloginLocator = By.name("userName");
	By registerNameField = By.cssSelector("input[name='userName']");
	By registerPasswordField = By.cssSelector("input[name='password']");
	By signinBtnLocator = By.name("login");
	By pageAfterLogin = By.xpath("//img[@src='/images/nav/logo.gif']");


	@Before
	public void setUp() throws Exception {

		System.setProperty("webdriver.chrome.driver", "./src/test/resources/chromedriver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://newtours.demoaut.com/");
	}

	@After
	public void tearDown() throws Exception {
		//driver.quit();

	}

	@Test

	/*
	 * Three steps* 1)Click on register link 2)Complete user text fields 3)Confirm
	 * user successfully registered message
	 */
	public void registerUser() throws InterruptedException {

		driver.findElement(registerLinkLocator).click();
		Thread.sleep(2000);
		if (driver.findElement(registerPageLocator).isDisplayed()) {

			driver.findElement(userNameLocator).sendKeys("Admin");
			driver.findElement(passwordLocator).sendKeys("pass1");
			driver.findElement(confirmPasswordLocator).sendKeys("pass1");

			driver.findElement(registerBtnLocator).click();

		} else {
			System.out.println("Register page was not found");
		}

		List<WebElement> fonts = driver.findElements(By.tagName("font"));

		assertEquals("Note: Your user name is Admin.", fonts.get(5).getText());

	}

	@Test
	public void signIn() throws InterruptedException {

		if (driver.findElement(userNameloginLocator).isDisplayed()) {
			driver.findElement(registerNameField).sendKeys("Admin");
			driver.findElement(registerPasswordField).sendKeys("pass1");
			driver.findElement(signinBtnLocator).click();
			Thread.sleep(5000);
			assertTrue(driver.findElement(pageAfterLogin).isDisplayed());

		} else
			System.out.println("Username text box was not present");
	}
}
