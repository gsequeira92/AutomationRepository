package Test.Olenick.Automation.tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AmazonProductDetailPage extends Base {

	public AmazonProductDetailPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(this.driver, this);
	}

	@FindBy(css = "input[class=nav-input]")
	WebElement confirmSearch;

	@FindBy(id = "twotabsearchtextbox")
	WebElement searchBoxField;

	@FindBy(id = "buy-now-button")
	WebElement buyNowBtn;

	@FindBy(css = "select#searchDropdownBox")
	WebElement departmentButton;

	public void textSearchProduct(String product) {

		searchBoxField.click();

		searchBoxField.sendKeys(product);

		confirmSearch.click();

	}

	public void searchByDepartament(int index) {

		departmentButton.click();
		;
		// dropdownByIndex(index, departmentButton);

	}

	public void buyProductNow() {

		buyNowBtn.click();

	}

}
