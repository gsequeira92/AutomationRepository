package pom;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RegisterPage extends Base {

	By registerLinkLocator = By.linkText("REGISTER");
	By registerPageLocator = By.xpath("//img[@src='/images/nav/logo.gif']");
	By userNameLocator = By.id("email");
	By passwordLocator = By.name("password");
	By confirmPasswordLocator = By.cssSelector("input[name='confirmPassword']");
	By registerBtnLocator = By.name("register");
	By registeredMessage = By.tagName("font");

	public RegisterPage(WebDriver driver) {
		super(driver);

	}

	public void registerUser() throws InterruptedException {

		click(registerLinkLocator);

		Wait(registerPageLocator);

		if (isDisplayed(registerPageLocator)) {
			type("admin", userNameLocator);
			type("pass1", passwordLocator);
			type("pass1", confirmPasswordLocator);
			click(registerBtnLocator);

		} else {
			System.out.println("Register page was not found");
		}

	}

	public String registerMessage() {

		List<WebElement> fonts = findElements(registeredMessage);

		return getText(fonts.get(5));

	}
}
