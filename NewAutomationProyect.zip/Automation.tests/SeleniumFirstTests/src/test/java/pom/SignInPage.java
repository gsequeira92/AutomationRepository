package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SignInPage extends Base {

	By userNameloginLocator = By.name("userName");
	By registerNameField = By.cssSelector("input[name='userName']");
	By registerPasswordField = By.cssSelector("input[name='password']");
	By signinBtnLocator = By.name("login");
	By pageAfterLogin = By.xpath("//img[@src='/images/nav/logo.gif']");

	public SignInPage(WebDriver driver) {
		super(driver);

	}

	public void signIn() {

		if (isDisplayed(userNameloginLocator)) {
			type("admin", registerNameField);
			type("pass1", registerPasswordField);
			click(signinBtnLocator);

		} else {
			System.out.println("Username textbox was not present");
		}

	}

	public boolean isHomePageDisplayed() {
		new WebDriverWait(this.driver, 2000).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(pageAfterLogin));
		return isDisplayed(pageAfterLogin);
	}

}
